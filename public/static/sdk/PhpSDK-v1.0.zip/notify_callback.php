<?php
include_once './class.brother.php';

//接口域名例子  http://baidu.com   这样即可
$brother = new brother('接口域名', '您的商户号', '您的密匙');

$getData = $_GET;
$pid     = $getData['pid'];
//商户号
$tradeNo = $getData['trade_no'];
//小老弟订单号
$tradeNoOut = $getData['out_trade_no'];
//	商户系统内部的订单号
$payType = $getData['type'];
//alipay:支付宝,tenpay:财付通,
//qqpay:QQ钱包,wxpay:微信支付,
//alipaycode:支付宝扫码,jdpay:京东支付
$productName = $getData['name'];
//商品名称
$money    = $getData['money'];
$status   = $getData['trade_status'];
$sign     = $getData['sign'];
$signType = $getData['sign_type'];

if ($signType != 'MD5')
    exit('验证签名算法不支持！');
if ($brother->buildSign($getData) != $getData['sign'])
    exit('签名效验不正确！');

//下面做你想做的事情

//这里做你爱做的是

//下面是输出
return '<h1 style="text-align: center;">您已经成功支付</h1>';