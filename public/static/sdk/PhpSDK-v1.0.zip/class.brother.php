<?php
/**
 * Created by PhpStorm.
 * User: Fleey-Pc
 * Date: 2019/3/2
 * Time: 8:32
 */

class brother
{
    private $partner;
    //商户号
    private $key;
    //商户密匙
    private $apiDomain;

    //接口网关
    public function __construct($apiDomain, $partner, $key)
    {
        if (empty($partner) || empty($key) || empty($apiDomain))
            throw new Exception('商户号或密匙或接口地址不能为空');

        $this->partner   = $partner;
        $this->key       = $key;
        $this->apiDomain = $apiDomain;
    }

    /**
     * 获取支付二维码 目前仅支持 支付宝 微信
     * @param $notifyUrl
     * @param $outTradeNo
     * @param $name
     * @param $money
     * @param $payType
     * @return string
     */
    public function getQrCode($notifyUrl, $outTradeNo, $name, $money, $payType)
    {
        $param              = array(
            'pid'          => $this->partner,
            'type'         => $payType,
            'notify_url'   => $notifyUrl,
            'out_trade_no' => $outTradeNo,
            'name'         => $name,
            'money'        => $money
        );
        $param['sign_type'] = 'MD5';
        $param['sign']      = self::buildSign($param);
        $request            = self::curl($this->apiDomain . '/qrcode.php?' . self::createLinkString($param, true));
        if ($request === false)
            return 'curl 请求失败,请联系相关人员处理';
        $request = json_decode($request, true);
        if ($request['code'] != 1)
            return '获取二维码失败,请联系相关人员处理';
        return $request['code_url'];
    }

    /**
     * 查询订单
     * @param $tradeNo //单号
     * @param string $type //平台订单号 trade_no  商户订单号 out_trade_no
     * @return mixed
     */
    public function searchOrder($tradeNo, $type = 'out_trade_no')
    {
        $param = array(
            'act' => 'order',
            'pid' => $this->partner,
            'key' => $this->key
        );
        if ($type == 'trade_no')
            $param['trade_no'] = $tradeNo;
        else
            $param['out_trade_no'] = $tradeNo;
        $requestResult = self::curl($this->apiDomain . '/api.php?' . self::createLinkString($param, true));
        return json_decode($requestResult, true);
    }

    /**
     * 创建支付链接
     * @param $notifyUrl //异步回调地址
     * @param $returnUrl //同步回调地址
     * @param $outTradeNo //您的订单ID
     * @param $name //商品名称
     * @param $money //支付金额
     * @param $siteName //站点名称
     * @param $payType //支付类型
     * @return string
     */
    public function getPayUrl($notifyUrl, $returnUrl, $outTradeNo, $name, $money, $siteName, $payType)
    {
        $param              = array(
            'pid'          => $this->partner,
            'type'         => $payType,
            'notify_url'   => $notifyUrl,
            'return_url'   => $returnUrl,
            'out_trade_no' => $outTradeNo,
            'name'         => $name,
            'money'        => $money,
            'sitename'     => $siteName
        );
        $param['sign_type'] = 'MD5';
        $param['sign']      = self::buildSign($param);
        return $this->apiDomain . '/submit.php' . '?' . self::createLinkString($param, true);
    }

    /**
     * 过滤参数
     * @param $para
     * @return array
     */
    public static function paraFilter($para)
    {
        $para_filter = array();
        foreach ($para as $key => $val) {
            if ($key == 'sign' || $key == 'sign_type' || empty($val))
                continue;
            else
                $para_filter[$key] = $val;
        }
        return $para_filter;
    }

    /**
     * 对数组排序
     * @param $para array//排序前的数组
     * @return array //排序后的数组
     */
    public static function argSort($para)
    {
        ksort($para);
        reset($para);
        return $para;
    }

    /*
    * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
    * @param $para array//需要拼接的数组
    * @return string//拼接完成以后的字符串
    */
    public static function createLinkString($para, $isUrlEncode = false)
    {
        $arg = '';
        foreach ($para as $key => $val) {
            if ($isUrlEncode)
                $arg .= $key . '=' . urlencode($val) . '&';
            else
                $arg .= $key . '=' . $val . '&';
        }
        //去掉最后一个&字符
        $arg = substr($arg, 0, strlen($arg) - 1);

        //如果存在转义字符，那么去掉转义
        if (get_magic_quotes_gpc()) {
            $arg = stripslashes($arg);
        }

        return $arg;
    }

    /**
     * curl封装函数
     * @param string $url
     * @param array $addHeaders
     * @param string $requestType
     * @param string $requestData
     * @param string $postType
     * @param bool $urlencode
     * @return bool|string
     */
    public static function curl($url = '', $addHeaders = [], $requestType = 'get', $requestData = '', $postType = '', $urlencode = true)
    {
        if (empty($url))
            return '';
        //容错处理
        $headers  = [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'
        ];
        $postType = strtolower($postType);
        if ($requestType != 'get') {
            if ($postType == 'json') {
                $headers[]   = 'Content-Type: application/json; charset=utf-8';
                $requestData = is_array($requestData) ? json_encode($requestData) : $requestData;
            } else if ($postType == 'xml') {
                $headers[] = 'Content-Type:text/xml; charset=utf-8';
            }
            $headers[] = 'Content-Length: ' . strlen($requestData);
        }
        if ($requestType == 'get' && is_array($requestData)) {
            $tempBuff = '';
            foreach ($requestData as $key => $value) {
                $tempBuff .= $key . '=' . $value . '&';
            }
            $tempBuff = trim($tempBuff, '&');
            $url      .= '?' . $tempBuff;
        }
        //手动build get请求参数

        if (!empty($addHeaders))
            $headers = array_merge($headers, $addHeaders);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
//    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);

        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        //设置允许302转跳

//        curl_setopt($ch, CURLOPT_PROXYAUTH, CURLAUTH_BASIC);
//        curl_setopt($ch, CURLOPT_PROXY, ''); //代理服务器地址
//        curl_setopt($ch, CURLOPT_PROXYPORT, 1111); //代理服务器端口
        //set proxy
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
        //gzip

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        //add ssl
        if ($requestType == 'get') {
            curl_setopt($ch, CURLOPT_HEADER, false);
        } else if ($requestType == 'post') {
            curl_setopt($ch, CURLOPT_POST, 1);
        } else {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($requestType));
        }
        //处理类型
        if ($requestType != 'get') {
            if (is_array($requestData) && !empty($requestData)) {
                $temp = '';
                foreach ($requestData as $key => $value) {
                    if ($urlencode) {
                        $temp .= rawurlencode(rawurlencode($key)) . '=' . rawurlencode(rawurlencode($value)) . '&';
                    } else {
                        $temp .= $key . '=' . $value . '&';
                    }
                }
                $requestData = substr($temp, 0, strlen($temp) - 1);
            }
            curl_setopt($ch, CURLOPT_POSTFIELDS, $requestData);
        }
        //只要不是get姿势都塞东西给他post
        $result = curl_exec($ch);

        curl_close($ch);
        return $result;
    }

    /**
     * 构建签名
     * @param $param
     * @return string
     */
    public function buildSign($param)
    {
        $param = self::paraFilter($param);
        //param filter
        $param = self::argSort($param);
        //param sort
        $sign = md5(self::createLinkstring($param) . $this->key);

        return $sign;
    }

}