具体例子都在里面。。。剩下有些接口劳资懒得弄了 

一个周末就这样了

首先你得

```code
include_once './class.brother.php';
//接口域名例子  http://baidu.com   这样即可
$brother = new brother('接口域名', '您的商户号', '您的密匙');
```
然后你就随便当个调包大湿吧

```code
//发起支付请求教程
include_once './class.brother.php';
//接口域名例子  http://baidu.com   这样即可
$brother = new brother('接口域名', '您的商户号', '您的密匙');

$url = $brother->getPayUrl('回调地址','同步返回地址','你的平台单号','商品名称','1.01','网站名','alipay');

//你得想办法让用户访问这个链接 或者你自己骚操作封装也行
```